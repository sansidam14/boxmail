<?php
$host     = "localhost";    // Nama host
$username = "agensurat";         // Username database
$password = "anggakeren";   // Password database
$database = "agendasurat";   // Nama database
